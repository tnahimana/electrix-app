<?php echo e($slot); ?>

<?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter-api/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>