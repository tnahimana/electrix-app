<?php $__env->startComponent('mail::message'); ?>
<img src="<?php echo e(asset('electrix-home.png')); ?>" alt="">
<h1>We have received your request to reset your account password</h1>
<p>You can use the following code to recover your account:</p>

<?php $__env->startComponent('mail::panel'); ?>
<?php echo e($code); ?>

<?php echo $__env->renderComponent(); ?>

<p>The allowed duration of the code is one hour from the time the message was sent</p>
<?php echo $__env->renderComponent(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter-api/resources/views/emails/send-code-reset-password.blade.php ENDPATH**/ ?>