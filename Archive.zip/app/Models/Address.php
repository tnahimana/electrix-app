<?php

namespace App\Models;

use App\Models\Cell;
use App\Models\Sector;
use App\Models\Village;
use App\Models\District;
use App\Models\Province;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Address extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function province(){
        return $this->belongsTo(Province::class);
    }

    public function district(){
        return $this->belongsTo(District::class);
    }

    public function sector(){
        return $this->belongsTo(Sector::class);
    }

    public function cell(){
        return $this->belongsTo(Cell::class);
    }

    public function village(){
        return $this->belongsTo(Village::class);
    }
}
