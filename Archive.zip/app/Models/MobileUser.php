<?php

namespace App\Models;

use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Factories\HasFactory;


class MobileUser extends Model
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $table = 'mobile_users';

    protected $fillable = [
        'firstname',
        'middlename',
        'lastname',
        'email',
        'phone',
        'password',
        'user_id'
    ];

    protected $hidden = [
        'password',
    ];

    
}