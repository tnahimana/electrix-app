<?php

namespace App\Models;

use App\Models\RegMeter;
use App\Models\MobileUser;
use App\Models\ElectrixMeter;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Sale extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function regmeter(){
        return $this->belongsTo(RegMeter::class, 'reg_meter_id');
    }

    public function electrixmeter(){
        return $this->belongsTo(ElectrixMeter::class, 'electrix_meter_id');
    }

    public function user(){
        return $this->belongsTo(MobileUser::class, 'mobile_user_id');
    }
}
