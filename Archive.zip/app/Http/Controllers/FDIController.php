<?php

namespace App\Http\Controllers;

use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\ElectrixMeter;
use App\Models\FdiTransaction;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Http;

class FDIController extends Controller
{
    
    public function queryMeter(Request $request){
        $attrs = $request->validate([
            'meterno' => 'required | min:11'
        ]);
        $tstamp = intval(date('Y') . strval(Carbon::now()->timestamp));
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'username' => getenv('FDI_USERNAME'),
            'pin' => getenv('FDI_PIN')
        ])->get(getenv('FDI_ENDPOINT'), [
                'pdt' => 'electricity',
                'ep' => 'query',
                'meterno' => $attrs['meterno'],
                'tstamp' => $tstamp,
        ]);
       return $response = $response->json();   
    }

    public function queryLastToken(Request $request){
        $attrs = $request->validate([
            'meterno' => 'required | min:11'
        ]);
        $tstamp = intval(date('Y') . strval(Carbon::now()->timestamp));
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'username' => getenv('FDI_USERNAME'),
            'pin' => getenv('FDI_PIN')
        ])->get(getenv('FDI_ENDPOINT'), [
                'pdt' => 'electricity',
                'ep' => 'fetch',
                'meterno' => $attrs['meterno'],
                'token' => 3,
                'tstamp' => $tstamp,
        ]);
       return $response = $response->json(); 
    }

    public function generateElectricityToken(Request $request){
        $attrs = $request->validate([
            'meterNumber' => 'required | min:11',
            'units' => 'required'
        ]);
       $amount = floatval($attrs['units']) * 189; 
       $meter = $this->validateElectrixMeter($attrs['meterNumber']); 
       $url = getenv('ELECTRIX_ENDPOINT') . 'VendingMeter';
       if($meter){
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
        ])->post($url, [
            'CompanyName' => getenv('COMPANY_NAME'),
            'UserName' => getenv('USERNAME'),
            'PassWord' => getenv('PASSWORD'),
            'MeterID' => strVal($meter),
            'is_vend_by_unit' => "false",
            'Amount'=> strVal($amount)
        ]);
        
        return response([
            'data' => [
                'status' => true,
                'msg' => $meter . ' # Token has been generated successfully!',
                'response' => $response->json()[0],
                'token' => $response->json()[0]['Token'],
            ]
        ], 200);
       }else{
        return response([
            'data' => [
                'status' => false,
                'msg' => $meter . ' # meterno not doesn\'t exist',
                'token' => null,
            ]
        ], 200);
       }
    }

    public function generateRegToken(Request $request){
        $attrs = $request->validate([
            'meterno' => 'required | min:11',
            'amount' => 'required | numeric',
            'customer_msisdn' => 'required | min:12',
            'trxref' => 'required',
        ]);
        $tstamp = intval(date('Y') . strval(Carbon::now()->timestamp));
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'username' => getenv('FDI_USERNAME'),
            'pin' => getenv('FDI_PIN')
        ])->get(getenv('FDI_ENDPOINT'), [
                'pdt' => 'electricity',
                'ep' => 'vend',
                'meterno' => $attrs['meterno'],
                'amount' => $attrs['amount'],
                'customer_msisdn' => $attrs['customer_msisdn'],
                'trxref' => $attrs['trxref'],
                'tstamp' => $tstamp,
        ]);
       return $response = $response->json(); 
    }

    public function startimeSubscription(Request $request){
        $attrs = $request->validate([
            'smartcard' => 'required | min:11',
            'customer_msisdn' => 'required | min:12',
            'amount' => 'required | numeric',
            'trxref' => 'required',
        ]); 
        $tstamp = intval(date('Y') . strval(Carbon::now()->timestamp));
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'username' => getenv('FDI_USERNAME'),
            'pin' => getenv('FDI_PIN')
        ])->get(getenv('FDI_ENDPOINT'), [
                'pdt' => 'startimes_tv',
                'ep' => 'vend',
                'customer_msisdn' => $attrs['customer_msisdn'],
                'smartcard' => $attrs['smartcard'],
                'amount' => $attrs['amount'],
                'trxref' => $attrs['trxref'],
                'tstamp' => $tstamp,
        ]);
       return $response = $response->json();  
    }

    public function airtimeTopup(Request $request){
        $attrs = $request->validate([
            'customer_msisdn' => 'required | min:12',
            'amount' => 'required | numeric',
            'trxref' => 'required',
        ]); 
        $tstamp = intval(date('Y') . strval(Carbon::now()->timestamp));
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'username' => getenv('FDI_USERNAME'),
            'pin' => getenv('FDI_PIN')
        ])->get(getenv('FDI_ENDPOINT'), [
                'pdt' => 'airtime',
                'ep' => 'vend',
                'customer_msisdn' => $attrs['customer_msisdn'],
                'amount' => $attrs['amount'],
                'trxref' => $attrs['trxref'],
                'tstamp' => $tstamp,
        ]);
       return $response = $response->json();  
    }

    public function balanceRequest(Request $request){
        $tstamp = intval(date('Y') . strval(Carbon::now()->timestamp));
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'username' => getenv('FDI_USERNAME'),
            'pin' => getenv('FDI_PIN')
        ])->get(getenv('FDI_STATUS'), [
                'pdt' => 'wallet',
                'ep' => 'balance',
                'tstamp' => $tstamp,
        ]);
       return $response = $response->json();  
    }

    public function validateElectrixMeter($meterNumber){
        $meter = ElectrixMeter::where('electrix_meter_number', $meterNumber)->with('regmeter')->first();
        if($meter != ''){
            return $meter->electrix_meter_number;
        }
        else{
            return null;
        }
    }

    public function fdiTransaction(Request $request){
        $attrs = $request->validate([
            'transaction_type' => 'required',
            'transaction_data' => 'required',
            'customer_msisdn' => 'required',
        ]);

        $data = FdiTransaction::create([
            'user_id' => auth()->user()->id,
            'customer_msisdn' => $attrs['customer_msisdn'],
            'transaction_type' => $attrs['transaction_type'],
            'transaction_data' => $attrs['transaction_data'],
            'resolve_status' => 0,
        ]);
        if($data){
            return response([
                'data' => $data
            ], 200);
        }
    }

    public function retrieveFdiTrancactions(){
        return response([
            'fdi_transactions' => FdiTransaction::where('transaction_type', '!=', 'electrix_electricity')->latest()->get()
        ],200);
    }
    
    
    public function getFdiTrancactions($id){
        $fdi = FdiTransaction::find($id);
        
        return response([
            'fdi_transactions' => [
                'id' => $fdi->id,
                'user_id' => $fdi->user_id,
                'customer_msisdn' => $fdi->customer_msisdn,
                'transaction_type' => $fdi->transaction_type,
                'transaction_data' => $fdi->transaction_data,
                'resolve_status' => $fdi->resolve_status,
                'created_at' => $fdi->created_at->format('D,d-M-Y  g:i A'),
            ]
            ],200);
    }
}