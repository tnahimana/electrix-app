<?php

namespace App\Http\Controllers;

use App\Models\Constant;
use Illuminate\Http\Request;

class ConstantController extends Controller
{
    public function index(){
        $constants = Constant::get();
        $array = [];
        foreach($constants as $item){
            array_push($array,[
                $item->name => $item->value, 
            ]);
        }
        return response([
            'constants' => $array,
        ],200);
    }
}