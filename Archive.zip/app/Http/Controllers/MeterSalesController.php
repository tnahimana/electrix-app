<?php

namespace App\Http\Controllers;

use App\Models\Sale;
use App\Models\Constant;
use App\Models\Transaction;
use Illuminate\Http\Request;
use App\Models\ElectrixMeter;
use App\Models\RegMeter;
use Illuminate\Support\Carbon;

class MeterSalesController extends Controller
{
    public function sales(){
        return response([
            'sales' => Sale::where('mobile_user_id', auth()->user()->mobileUser->id)
                             ->with('regmeter', 'electrixmeter')->limit(10)->latest()->get(),
        ],200);
    }

    public function sale($id){
        $sale = Sale::with('regmeter', 'electrixmeter')->find($id);
        if($sale->subscription_status){
            $status = true;
        }else{
            $status = false;
        }
        return response([
            'sales' => [
                'id' => $sale->id,
                'initial_cost' => $sale->initial_cost,
                'created_at' => $sale->created_at->format('D,d-M-Y  g:i A'),
                'token_cost' => $sale->token_cost,
                'token_cost' => $sale->token_cost,
                'units' => $sale->units,
                'reg_meter_token' => $sale->reg_meter_token,
                'electrix_meter_token' => $sale->electrix_meter_token,
                'reg_meter_number' => $sale->regmeter->reg_meter_number,
                'electrix_meter_number' => $sale->electrixmeter->electrix_meter_number,
                'firstname' => $sale->regmeter->client->firstname,
                'lastname' => $sale->regmeter->client->lastname,
                'subscription' => $status,
            ]
            ],200);
    }

    public function validateMeter($id){
        $meter = ElectrixMeter::where('electrix_meter_number', $id)->with('regmeter')->first();

        if($meter != ''){
            return response([
                'meter' => [
                    'reg_meter_number' => $meter->regmeter->reg_meter_number,
                    'meter_owner' => $meter->regmeter->client->firstname . " " . $meter->regmeter->client->lastname,
                    'meter_status' => $meter->meter_status,
                    'user_id' => auth()->user()->mobileUser->id,
                    'reg_meter_id' => $meter->regmeter->id,
                    'electrix_meter_id' =>$meter->id,
                    'meter_type' => $meter->regmeter->meter_type,
                ]
            ],200);
        }
        else
        {
            return response([
                'meter' => [
                    'reg_meter_number' => null,
                    'meter_owner' => null,
                    'meter_status' => null,
                    'meter_type' => null,
                ]
            ],200);
        }
    }

    public function saleStore(Request $request){
        $attrs = $request->validate([
            'userId' => 'required',
            'regId' => 'required',
            'electrixId' => 'required',
            'initialCost'=> 'required',
            'tokenCost' => 'required',
            'regToken' => 'required',
            'electrixToken' => 'required',
            'units' => 'required',
            'subscription_status' => 'required',
        ]);
        $sale = Sale::create([
            'mobile_user_id' => $attrs['userId'],
            'reg_meter_id' => $attrs['regId'],
            'electrix_meter_id' => $attrs['electrixId'],
            'initial_cost' => $attrs['initialCost'],
            'token_cost' => $attrs['tokenCost'],
            'reg_meter_token' => $attrs['regToken'],
            'electrix_meter_token' => $attrs['electrixToken'],
            'units' => $attrs['units'],
            'subscription_status'=> $attrs['subscription_status'], 
        ]);

        return response([
            'sale' => $sale,
        ], 200);
    }

    public function monthlySales($id){
        $meter = ElectrixMeter::where('electrix_meter_number', $id)->with('regmeter')->first();
        $last_sales = Sale::where('electrix_meter_id', $meter->id)->latest()->first();
        $sales = Sale::where('reg_meter_id', $meter->reg_meter_id)->whereMonth('created_at', Carbon::now()->month)->sum('token_cost');
        $monthlySubscription = Sale::where('subscription_status', true)->where('electrix_meter_id', $meter->id)->whereMonth('created_at', Carbon::now()->month)->latest()->first();
        if($monthlySubscription != ""){
            $status = true;
        }else{
            $status = false;
        }
        if($last_sales == null && $meter->regmeter->meter_type == 'Residential'){
            $sales = '12000';
        }else if($last_sales == null && $meter->regmeter->meter_type == 'Commercial'){
            $sales = '10000';

        }
        return response([
            'sales' => [
                'sales_amount' => $sales,
                'subscription' => $status,
            ]
        ],200);
    }

    public function saleUpdate($id){
        $sale_id = Sale::where('electrix_meter_id', $id)->orderBy('id', 'DESC')->first();
        $sale = Sale::where('id', $sale_id->id)->update([
            'commussion_status' => 'Paid',
        ]);

        return response([
            'sale' => $sale_id,
        ],200);
    }

    public function saleRedirect($id){
        $sale = Sale::with('regmeter', 'electrixmeter')->where('electrix_meter_id',$id)->orderBy('id', 'DESC')->first();

        return response([
            'sale' => [
                'id' => $sale->id,
                'initial_cost' => $sale->initial_cost,
                'created_at' => $sale->created_at->format('d.M.Y  g:i A'),
                'token_cost' => $sale->token_cost,
                'units' => $sale->units,
                'reg_meter_token' => $sale->reg_meter_token,
                'electrix_meter_token' => $sale->electrix_meter_token,
                'reg_meter_number' => $sale->regmeter->reg_meter_number,
                'electrix_meter_number' => $sale->electrixmeter->electrix_meter_number,
                'firstname' => $sale->regmeter->client->firstname,
                'lastname' => $sale->regmeter->client->lastname,
            ]
            ],200);
    }

    public function validateTransaction($txId){
        $transaction = Transaction::where('txId', $txId)->first();
        if($transaction != ""){
            return response([
                'transaction' => [
                    'txId' => $transaction->txId,
                    'timeStamp' => $transaction->timeStamp,
                ],
            ],200);
        }else if($transaction == ""){
            return response([
                'transaction' => [
                    'txId' => "",
                    'timeStamp' => "",
                ],
            ],200); 
        }
    }

    public function storeTransaction(Request $request){
        $attrs = $request->validate([
            'txId' => 'required',
            'network' => 'required',
            'timeStamp' => 'required',
        ]);

        $transaction = Transaction::create([
            'txId' => $attrs['txId'],
            'network' => $attrs['network'],
            'timeStamp' => $attrs['timeStamp'],
        ]);

        return response([
            'transaction' => $transaction,
        ], 200);

    }

    public function constants(){
        return response([
            'constants' => Constant::get()
        ], 200);
    }

    public function regValidate($id){
        $meter = RegMeter::where('reg_meter_number', $id)->first();
        if($meter != ""){
            return response([
                'meter' => [
                    'meter_number' => $meter->reg_meter_number,
                ],
            ], 200);
        }else{
            return response([
                'meter' => [
                    'meter_number' => '',
                ],
            ], 200);
        }
    }
}