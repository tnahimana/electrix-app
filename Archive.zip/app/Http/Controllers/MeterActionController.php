<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ElectrixMeter;
use App\Models\TokenGenerate;
use Illuminate\Support\Facades\Http;

class MeterActionController extends Controller
{
    public $token;

    public function clearTamper(Request $request){
        $validated = $request->validate([
            'meter_number' => 'required | digits:11'
        ]);
        $electrix_id = ElectrixMeter::where('electrix_meter_number', $request->meter_number)->first();
        if($electrix_id != ""){
            $token = str_replace(" ","-", $this->generateClearTamperToken($request->meter_number));
            $saveGeneratedToken = TokenGenerate::create([
                'user_id' => auth()->user()->id,
                'electrix_meter_id' => $electrix_id->id,
                'token' => $token,
                'token_type' => 'clear_tamper-app',
            ]);
            if($saveGeneratedToken){
                return response([
                    'tamper_token' => $token
                ], 200);
            }
        }else{
            return response([
                'tamper_token' => "Invalid Meter Number"
            ], 200);
        }
    }

    public function clearCredit(Request $request){
        $validated = $request->validate([
            'meter_number' => 'required | digits:11'
        ]);
        $electrix_id = ElectrixMeter::where('electrix_meter_number', $request->meter_number)->first();
        if($electrix_id != ""){
            $token = str_replace(" ","-", $this->generateClearCreditToken($request->meter_number));
            $saveGeneratedToken = TokenGenerate::create([
                'user_id' => auth()->user()->id,
                'electrix_meter_id' => $electrix_id->id,
                'token' => $token,
                'token_type' => 'clear_credit-app',
            ]);
            if($saveGeneratedToken){
                return response([
                    'tamper_token' => $token
                ], 200);
            }
        }else{
            return response([
                'tamper_token' => "Invalid Meter Number"
            ], 200);
        }
    }
    
    public function generateClearTamperToken($meter_number){
        try {
            $meter = Http::post('http://www.newapi.stronpower.com/api/QueryMeterInfo',[
                "CompanyName"=> "Genius-Solutions",
                "UserName" => "Admin84",
                "PassWord" => "123456",
                "MeterId" => $meter_number
            ])->json();
            $custmer_id = $meter[0]['Customer_id'];
            $response = Http::post('http://www.newapi.stronpower.com/api/ClearTamper',[
                "CompanyName" => "Genius-Solutions",
                "UserName" =>"Admin84",
                "PassWord" => "123456",
                "CustomerID" => $custmer_id,
                "METER_ID" => $meter_number
            ]);
            $result = $response->json();
            $split = explode(',',$result);
            $this->token = $split[0];
        } catch (\Throwable $th) {
            return $this->token = 'Error';
        }
        return $this->token;
    }

    public function generateClearCreditToken($meter_number){
        try {
            $meter = Http::post('http://www.newapi.stronpower.com/api/QueryMeterInfo',[
                "CompanyName"=> "Genius-Solutions",
                "UserName" => "Admin84",
                "PassWord" => "123456",
                "MeterId" => $meter_number
            ])->json();
            $custmer_id = $meter[0]['Customer_id'];
            $response = Http::post('http://www.newapi.stronpower.com/api/ClearCredit',[
                "CompanyName" => "Genius-Solutions",
                "UserName" =>"Admin84",
                "PassWord" => "123456",
                "CustomerID" => $custmer_id,
                "METER_ID" => $meter_number
            ]);
            $result = $response->json();
            $split = explode(',',$result);
            $this->token = $split[0];
        } catch (\Throwable $th) {
            return $this->token = 'Error';
        }
        return $this->token;
    } 

}