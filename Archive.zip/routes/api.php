<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FDIController;
use App\Http\Controllers\ConstantController;
use App\Http\Controllers\CodeCheckController;
use App\Http\Controllers\MeterSalesController;
use App\Http\Controllers\MobileUserController;
use App\Http\Controllers\MeterActionController;
use App\Http\Controllers\ResetPasswordController;
use App\Http\Controllers\ForgotPasswordController;



Route::post('/login',[MobileUserController::class, 'login']);
Route::post('/register',[MobileUserController::class, 'register']);
Route::get('/update-releases',[MobileUserController::class, 'updateRelease']);
Route::post('/password/email',  ForgotPasswordController::class);
Route::post('/password/code/check', CodeCheckController::class);
Route::post('/password/reset', ResetPasswordController::class);

Route::group(['middleware' => ['auth:sanctum']], function(){
    Route::post('/logout',[MobileUserController::class, 'logout']);
    Route::get('/user',[MobileUserController::class, 'user']);
    Route::get('/sales',[MeterSalesController::class, 'sales']);
    Route::get('/sale/{id}',[MeterSalesController::class, 'sale']);
    Route::get('/profile',[MobileUserController::class, 'profile']);
    Route::get('/validate/{id}',[MeterSalesController::class, 'validateMeter']);
    Route::post('/saleStore',[MeterSalesController::class, 'saleStore']);
    Route::get('/monthlySales/{id}',[MeterSalesController::class, 'monthlySales']);
    Route::put('/updateSale/{id}',[MeterSalesController::class, 'saleUpdate']);
    Route::get('/saleRedirect/{id}',[MeterSalesController::class, 'saleRedirect']);
    Route::get('/constants',[ConstantController::class, 'index']);
    Route::post('/clear-tamper', [MeterActionController::class, 'clearTamper']);
    Route::post('/clear-credit', [MeterActionController::class, 'clearCredit']);
    Route::get('/transaction-validate/{txId}', [MeterSalesController::class, 'validateTransaction']);
    Route::post('/store-transaction', [MeterSalesController::class, 'storeTransaction']);
    Route::post('/constants', [MeterSalesController::class, 'constants']);
    Route::get('/reg-validate/{id}', [MeterSalesController::class, 'regValidate']);
    Route::post('/query-meter', [FDIController::class, 'queryMeter']);
    Route::post('/query-last-token', [FDIController::class, 'queryLastToken']);
    Route::post('/generate-electricity-token', [FDIController::class, 'generateElectricityToken']);
    Route::post('/generate-reg-token', [FDIController::class, 'generateRegToken']);
    Route::post('/startime-subscription', [FDIController::class, 'startimeSubscription']);
    Route::post('/airtime-topup', [FDIController::class, 'airtimeTopup']);
    Route::post('/balance-request', [FDIController::class, 'balanceRequest']);
    Route::post('/fdi-transaction', [FDIController::class, 'fdiTransaction']);
    Route::get('/retrieve-fdi-transaction', [FDIController::class, 'retrieveFdiTrancactions']);
    Route::get('/get-fdi-transaction/{id}', [FDIController::class, 'getFdiTrancactions']);
});